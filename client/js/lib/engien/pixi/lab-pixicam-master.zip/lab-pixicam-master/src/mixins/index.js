var pixi = require('./pixi');

module.exports = {
  addContainerUpdates: function(){
    pixi();
  }
};