# A PIXI Camera System

Place all your objects in a world container which is rendered based on 2d camera transformation. 
So you can zoom & translate your world with any size (think of platformer, tilemap).

This world is a simple container so you can maintain other layers to render a HUD or menu on top of of your camera renderer world.

Camera use cases:

  + Zoom to a target
  + Zoom to fit a view area
  + Follow Target
  + Constrained View
  + Change Zoom Pivot